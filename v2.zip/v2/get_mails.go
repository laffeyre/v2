package main

import (
	"bufio"
	"crypto/tls"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/fatih/color"
)

var (
	save_file        string = "emails_found.txt"
	result_directory string = "./"
)

func extractEmailsFromHTML(htmlText string) []string {
	emailPattern := `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}`
	re := regexp.MustCompile(emailPattern)
	emails := re.FindAllString(htmlText, -1)
	return emails
}

func Email_Scanner(url_target string) {
	if url_target == "" {
		// fmt.Println("[Error] No URL to scan")
		return
	}
	red := color.New(color.FgRed).SprintFunc()
	green := color.New(color.FgGreen).SprintFunc()
	yellow := color.New(color.FgYellow).SprintFunc()
	if !strings.Contains(url_target, "http") {
		url_target = "http://" + url_target
	}
	header := http.Header{}
	header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36")
	session := &http.Client{Timeout: time.Second * 7, Transport: &http.Transport{TLSClientConfig: &tls.Config{InsecureSkipVerify: true}}}

	req, err := http.NewRequest("GET", fmt.Sprintf("%s", url_target), nil)
	if err != nil {
		fmt.Println(red("[Error] Creating new request:", err))
		return
	}

	res, err := session.Do(req)
	if err != nil {
		fmt.Println(red("[Email Finder] Request to : ", url_target, " Error:E2"))
		return
	}
	defer res.Body.Close()
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		fmt.Println(red("[Error] Reading response body failed:", err))
		return
	}
	bodyString := string(body)
	status_code := res.StatusCode
	emails := extractEmailsFromHTML(bodyString)
	if status_code == 200 && len(emails) > 0 {
		// fmt.Println(emails)
		fmt.Println(green("[ Email Finder ] ", res.Request.URL, " -> ", len(emails), " Emails Found"))

		file, err := os.OpenFile(save_file, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
		if err != nil {
			fmt.Println(red("[Error] Opening file failed:", err))
			return
		}
		defer file.Close()

		joined := strings.Join(emails, "\n")
		if _, err := file.WriteString(joined + "\n"); err != nil {
			fmt.Println(red("[Error] Writing to file failed:", err))
			return
		}
	} else {
		fmt.Println(yellow("[ Email Finder ] ", url_target, " -> Emails Not Found"))
	}
}

//	func main() {
//		url := "google.com/contact"
//		Email_Scanner(url)
//	}
func main() {
	args := os.Args

	if len(args) < 3 {
		fmt.Printf("Format: %s [list.txt] [threads] [save_file]\n", args[0])
		os.Exit(1)
	}

	if len(args) == 4 {
		save_file = args[3]
	} else {
		save_file = "env.txt"
	}

	// Mengecek apakah folder sudah ada
	if _, err := os.Stat(result_directory); os.IsNotExist(err) {
		// Membuat folder jika tidak ada
		err := os.Mkdir(result_directory, 0755)
		if err != nil {
			fmt.Println("Gagal membuat folder:", err)
			return
		}
		fmt.Println("Folder berhasil dibuat")
	} else {
		// fmt.Println("Folder sudah ada")
	}

	numThreads, err := strconv.Atoi(args[2])
	if err != nil {
		fmt.Println("Threads must be a number.")
		os.Exit(1)
	}

	urlsFile, err := os.Open(args[1])
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
	defer urlsFile.Close()

	scanner := bufio.NewScanner(urlsFile)
	var urls []string
	for scanner.Scan() {
		urls = append(urls, scanner.Text())
	}

	if len(urls) == 0 {
		fmt.Println("No URLs found in file.")
		os.Exit(1)
	}

	var wg sync.WaitGroup
	wg.Add(len(urls))

	jobs := make(chan string, len(urls))
	results := make(chan string, len(urls))

	for i := 0; i < numThreads; i++ {
		go worker(jobs, results)
	}

	path_contact := []string{"/contact", "/contact.php"}
	for _, url := range urls {
		for _, path := range path_contact {
			// fmt.Println(url + path)
			jobs <- url + path
		}
	}
	close(jobs)

	go func() {
		wg.Wait()
		close(results)
	}()

	for range results {
		// fmt.Println(res)
		wg.Done()
	}

	// fmt.Printf("\n[ END ]\n")
}

func worker(jobs <-chan string, results chan<- string) {
	for url := range jobs {
		Email_Scanner(url)
		results <- url
		// results <- result
	}
}
