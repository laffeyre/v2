"""
    @zeerx7 - 28-01-2024 - github.com/zeerx7
"""

import socket
import smtplib
import dns.resolver
import threading
from queue import Queue
from colorama import Fore, init
init(autoreset=True)

def get_mx(host):   
    # records = dns.resolver.query(host, 'MX')
    records = dns.resolver.resolve(host, 'MX')
    mxRecord = records[0].exchange
    mxRecord = str(mxRecord)

    return mxRecord

def verify_email(email, mxRecord):
    # Get local server hostname
    host = socket.gethostname()

    # SMTP lib setup (use debug level for full output)
    server = smtplib.SMTP()
    server.set_debuglevel(0)

    # SMTP Conversation
    server.connect(mxRecord)
    server.helo(host)
    server.mail('user1337@gmail.com')
    code, message = server.rcpt(email)
    server.quit()

    # Assume 250 as Success
    if code == 250:
        print(Fore.GREEN + f'[+] {email} is valid')
        with open('valid_emails.txt', 'a') as f:
            f.write(email + '\n')
    else:
        print(Fore.YELLOW + f'[-] {email} is not valid')

def single(email):
    try:
        domain = email.split('@')[1]
        mxRecord = get_mx(domain)
        # print(mxRecord)
        verify_email(email, mxRecord)
        # print(get_mx('gmail.scom'))
    
    except dns.resolver.NoAnswer:
        print(Fore.YELLOW + f'[-] {email} is not valid (NoAnswer)')
    except UnicodeError:
        print(Fore.YELLOW + f'[-] {email} is not valid (UnicodeError)')
    except dns.resolver.NXDOMAIN:
        print(Fore.YELLOW + f'[-] {email} is not valid (NXDOMAIN)')
    except OSError:
        print(Fore.RED + f'[-] {email} Connection timed out')
    except Exception as e:
        print(Fore.RED + f'[-] {email} is not valid ({e})')

def do_stuff(jobs):
    try:
        while not jobs.empty():
            job = jobs.get(block=False)
            single(job)
            jobs.task_done()
    finally:
        pass

def main():
    print('\n\n')
    print(f'{Fore.CYAN}  [  Email Verifier * by @Zeerx7 * 28-01-2024 ]')
    print('\n\n')

    # single('zeerx7@gmail.com')
    thread = 15
    filename = input(f'{Fore.YELLOW}[?] Enter list file [emails]: {Fore.GREEN}')
    with open(filename, 'r') as f:
        emails = f.read().splitlines()

    jobs = Queue()
    for email in emails:
        if not email:
            continue
        jobs.put(email)

    for i in range(thread):
        t = threading.Thread(target=do_stuff, args=(jobs,))
        t.daemon = True
        t.start()
    
    jobs.join()
    print(Fore.GREEN + '\n\n[+] Done')

if __name__ == '__main__':
    socket.setdefaulttimeout(5)
    try:
        main()
    except FileNotFoundError:
        print(Fore.RED + '[-] File not found')