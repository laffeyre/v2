#!/usr/bin/python3
import socks
import socket
import requests
import threading
import ipaddress
import random
import re
import json
import os
import string
from queue import Queue
from colorama import Fore, init

# Initialize colorama for colored output
init(autoreset=True)

# Configure the SOCKS5 proxy settings with username and password
proxy_ip = "212.68.187.210"
proxy_port = 50101
proxy_username = "dN2Ehgpb"
proxy_password = "D5VbtHBkqZ"

print(f"{Fore.CYAN}Configuring SOCKS5 proxy...")
print(f"{Fore.YELLOW}Proxy: {proxy_ip}:{proxy_port}")
print(f"{Fore.YELLOW}Username: {proxy_username}")

# Set up the SOCKS5 proxy
try:
    socks.set_default_proxy(socks.SOCKS5, proxy_ip, proxy_port, True, proxy_username, proxy_password)
    socket.socket = socks.socksocket  # Monkey patch socket to use SOCKS proxy globally
    print(f"{Fore.GREEN}✓ Proxy configuration successful")
except Exception as e:
    print(f"{Fore.RED}✗ Proxy configuration failed: {e}")
    exit(1)

# Function to test proxy connection
def test_proxy():
    """Test the proxy connection and return IP information"""
    try:
        print(f"\n{Fore.CYAN}Testing proxy connection...")
        response = requests.get("http://httpbin.org/ip", timeout=10)
        
        if response.status_code == 200:
            ip_data = response.json()
            proxy_ip_used = ip_data.get('origin', 'Unknown')
            print(f"{Fore.GREEN}✓ Proxy working successfully")
            print(f"{Fore.YELLOW}Current IP: {proxy_ip_used}")
            return proxy_ip_used
        else:
            print(f"{Fore.RED}✗ HTTP Error: {response.status_code}")
            return None
            
    except requests.exceptions.RequestException as e:
        print(f"{Fore.RED}✗ Request error: {e}")
        return None
    except Exception as e:
        print(f"{Fore.RED}✗ Unexpected error: {e}")
        return None

# Function to get real IP (without proxy) for comparison
def get_real_ip():
    """Get real IP address without proxy"""
    try:
        print(f"\n{Fore.CYAN}Getting real IP for comparison...")
        
        # Store the current socket
        proxy_socket = socket.socket
        
        # Temporarily restore original socket
        import socket as socket_module
        socket.socket = socket_module.socket
        
        response = requests.get("http://httpbin.org/ip", timeout=5)
        
        # Restore proxy socket
        socket.socket = proxy_socket
        
        if response.status_code == 200:
            ip_data = response.json()
            real_ip = ip_data.get('origin', 'Unknown')
            print(f"{Fore.YELLOW}Real IP: {real_ip}")
            return real_ip
        else:
            print(f"{Fore.RED}✗ Failed to get real IP")
            return None
            
    except Exception as e:
        print(f"{Fore.RED}✗ Error getting real IP: {e}")
        # Ensure proxy socket is restored
        socket.socket = proxy_socket
        return None

# Function to test multiple endpoints
def test_multiple_endpoints():
    """Test proxy with multiple endpoints"""
    endpoints = [
        "http://httpbin.org/ip",
        "http://icanhazip.com",
        "http://ipinfo.io/ip"
    ]
    
    print(f"\n{Fore.CYAN}Testing multiple endpoints...")
    
    for endpoint in endpoints:
        try:
            print(f"{Fore.YELLOW}Testing: {endpoint}")
            response = requests.get(endpoint, timeout=10)
            
            if response.status_code == 200:
                content = response.text.strip()
                # Try to parse as JSON if possible
                try:
                    json_data = response.json()
                    if 'origin' in json_data:
                        content = json_data['origin']
                    elif 'ip' in json_data:
                        content = json_data['ip']
                except:
                    pass
                
                print(f"{Fore.GREEN}  ✓ Success: {content}")
            else:
                print(f"{Fore.RED}  ✗ HTTP {response.status_code}")
                
        except Exception as e:
            print(f"{Fore.RED}  ✗ Error: {str(e)[:50]}...")

# Main execution
if __name__ == "__main__":
    print(f"{Fore.MAGENTA}{'='*50}")
    print(f"{Fore.MAGENTA}    SOCKS5 Proxy Testing Script")
    print(f"{Fore.MAGENTA}{'='*50}")
    
    # Test basic proxy functionality
    proxy_ip_result = test_proxy()
    
    # Get real IP for comparison
    real_ip_result = get_real_ip()
    
    # Test multiple endpoints
    test_multiple_endpoints()
    
    # Summary
    print(f"\n{Fore.MAGENTA}{'='*50}")
    print(f"{Fore.MAGENTA}    SUMMARY")
    print(f"{Fore.MAGENTA}{'='*50}")
    
    if proxy_ip_result and real_ip_result:
        if proxy_ip_result != real_ip_result:
            print(f"{Fore.GREEN}✓ Proxy is working correctly!")
            print(f"{Fore.YELLOW}  Real IP: {real_ip_result}")
            print(f"{Fore.YELLOW}  Proxy IP: {proxy_ip_result}")
        else:
            print(f"{Fore.RED}✗ Proxy may not be working - IPs are the same")
    elif proxy_ip_result:
        print(f"{Fore.YELLOW}⚠ Proxy connected, but couldn't verify real IP")
        print(f"{Fore.YELLOW}  Current IP: {proxy_ip_result}")
    else:
        print(f"{Fore.RED}✗ Proxy connection failed")
    
    print(f"{Fore.MAGENTA}{'='*50}")

save_revip_file = "default.txt" 
tmp_folder = "tmp"
try:os.mkdir(tmp_folder)
except:pass

# if not exist get_mails.exe or get_mails
if not (os.name == 'nt' and os.path.exists("get_mails.exe")) and not (os.name != 'nt' and os.path.exists("get_mails")):
    print("[-] get_mails.exe or get_mails not found")
    print("[+] Compiling get_mails.go")
    os.system("go build get_mails.go")

# if platform is windows
if os.name == 'nt':
    cmd = "get_mails.exe"
else:
    cmd = "./get_mails"

def generate_random(length):
    characters = string.ascii_letters + string.digits
    random_text = ''.join(random.choice(characters) for _ in range(length))
    return random_text

def print_dev(value):
    if dev:
        print(value)


def reverse_ip(domain):
    try:
        ip = socket.gethostbyname(domain)
        request = requests.Request(
            'GET', f'https://s10.reverseipdomain.com/?api_key={api_key}&ip={ip}&limit=5000', headers=Headers)
        prepped = session.prepare_request(request)
        req = session.send(prepped, timeout=30)
        if req.status_code == 200:
            res = json.loads(req.text)
            if res:
                return res['result']
    except Exception as e:
        print_dev(e)


def range_ip(ip):
    ip = ip[:ip.rfind(".")]
    ranged = [str(ipres) for ipres in ipaddress.IPv4Network(f'{ip}.0/24')]
    random.shuffle(ranged)
    return ranged


def extract_emails_from_html(html_text):
    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
    emails = re.findall(email_pattern, html_text)
    return emails


def single_start(list):
    try:
        ipc = socket.gethostbyname(list)
        if not ipc:
            return
        range_ip_res = range_ip(ipc)
        for ip in range_ip_res:
            jobs_reverseip.put(ip)

        global total_thread_reverseip_runing
        if range_ip_res and total_thread_reverseip_runing <= max_revip_threads:
            threading.Thread(target=do_stuff_reverseip,
                             args=(jobs_reverseip,)).start()
            total_thread_reverseip_runing += 1

    except Exception as e:
        print_dev(e)


def single_start_reverseip(list):
    try:
        domains_res = reverse_ip(list)
        if domains_res:
            print(
                f'{Fore.GREEN}[Reverse IP] {list} -> Got {len(domains_res)} Domain')
            domainsx = "\n".join(domains_res)
            save_reverse_ip.write(f'{domainsx}\n')
            save_reverse_ip.flush()
            del domainsx

            fname = generate_random(15)+".txt"
            with open(tmp_folder+"/"+fname, "w") as file:
                file.write("\n".join(domains_res))

            thread = len(domains_res)
            if thread <= 3:thread = 1
            if thread >= 100:thread = 100
            os.system(f'{cmd} {tmp_folder}/{fname} {thread} emails_found.txt')
            try:os.remove(tmp_folder+"/"+fname)
            except:pass

        else:
            print(f'{Fore.RED}[Reverse IP] {list} -> Domains Not Found')

    except Exception as e:
        print_dev(e)

def do_stuff_reverseip(jobs):
    try:
        while not jobs.empty():
            job = jobs.get(block=False)
            single_start_reverseip(job)
            jobs.task_done()
    finally:
        global total_thread_reverseip_runing
        if total_thread_reverseip_runing > 0:
            total_thread_reverseip_runing -= 1


def do_stuff(jobs):
    while not jobs.empty():
        job = jobs.get(block=False)
        single_start(job)
        jobs.task_done()


def main():
    print('\n\n')
    print(f'{Fore.CYAN}  [  Range IP -> Reverse IP -> Get Emails  ]')
    print(f'{Fore.MAGENTA}                 by @Zeerx7 * 07-08-2023')
    print('\n\n')
    filename = input(f'{Fore.YELLOW}[?] Enter list file [ips/domains]: {Fore.GREEN}')
    # filename = 'a.txt'
    threads = 100
    try:
        threads = int(input(f'{Fore.YELLOW}[?] Enter threads [default: {threads}]: {Fore.GREEN}'))
        # threads = 100
    except:
        pass
    try:
        lists = open(filename, 'r').read().splitlines()
    except FileNotFoundError:
        print(f'{Fore.YELLOW}File not found')
        exit()
    
    print(f'{Fore.CYAN}\n[+] Starting...')

    global max_revip_threads, max_emailsfind_threads
    max_revip_threads = threads
    max_emailsfind_threads = threads+int(threads/2)

    # print(f'{Fore.CYAN}[+] Threads: {threads}, Max Threads: {max_revip_threads}, Max Threads: {max_emailsfind_threads}')
    jobs = Queue()
    random.shuffle(lists)

    for list in lists:
        jobs.put(list)

    for i in range(threads):
        worker = threading.Thread(target=do_stuff, args=(jobs,))
        worker.start()

    jobs.join()

    # x= reverse_ip('1.1.1.1')
    # print(x)
    # n = range_ip('1.1.1.1')
    # print((n))


if __name__ == '__main__':
    # Initialize global variables
    session = requests.Session()
    path_contact_list = [
        '/contact.php', '/contact', '/contact-us', '/contact-us.html',
        '/about', '/about-us', '/team', '/support', '/help'
    ]
    Headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.2309.372 Safari/537.36'
    }
    api_key = 'fx1XMSLPEMF24S2E98'
    total_thread_reverseip_runing = 0
    max_revip_threads = 100
    total_thread_emailsfind_runing = 0
    max_emailsfind_threads = 100
    jobs_reverseip = Queue()

    save_emails = open('emails_found.txt', 'a')
    save_reverse_ip = open('reverse_result.txt', 'a')
    dev = False
    init()
    main()
