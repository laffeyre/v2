## [GUIDE] Range IP -> Reverse IP -> Get Emails

### Requirements
- Python3
- Golang

### Install dependencies
- pip3 install colorama
- pip3 install requests

### Usage
- python3 run.py
  - Enter the pathfile containing the list of IP/domains
  - Enter the number of threads

### Output
- The list of found emails will be saved in `emails_found.txt`
- The domain results in the reverse ip process will be stored in `reverse_result.txt`

--------------------------------------------------------------------

## [GUIDE] email_verifier.py

### Install dependencies
- pip3 install dnspython
- pip3 install colorama

### Usage
- python3 email_verifier.py
  - Enter the pathFile containing the email list
  
### Output
- Valid emails will be stored in the `valid_emails.txt` file